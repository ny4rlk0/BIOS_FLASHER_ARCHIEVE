package com.wch.multiport;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("ValidFragment")
public class DeviceMEMTestFragment extends Fragment {
	private static final String TAG = "DeviceMEMTestFragment";
	static Context DeviceMEMTestContext;
	MultiPortManager multiport;
	private EditText mem_DataLen0, mem_DataLen1, mem_DataText0, mem_DataText1;
	private Button mem_AddrWrite, mem_AddrRead, mem_DataRead, mem_DataWrite;
	MyOperator operator;
	
	// Empty Constructor
	public DeviceMEMTestFragment()
	{
	}
	
	/* Constructor */
	public DeviceMEMTestFragment(Context parentContext , MultiPortManager MultiPortContext)
	{
		DeviceMEMTestContext = parentContext;
		multiport = MultiPortContext;
	}
	
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
					Bundle savedInstanceState)
	{
		if(container == null) {
			return null;
		}
		View view = inflater.inflate(R.layout.mem_layout, container, false);
		
		mem_DataLen0 = (EditText) view.findViewById(R.id.mem_datalength1);
		mem_DataLen1 = (EditText) view.findViewById(R.id.mem_datalength2);
		mem_DataText0 = (EditText) view.findViewById(R.id.mem_data1);
		mem_DataText1 = (EditText) view.findViewById(R.id.mem_data2);
		mem_AddrWrite = (Button) view.findViewById(R.id.mem_addwrite);
		mem_AddrRead = (Button) view.findViewById(R.id.mem_addread);
		mem_DataWrite = (Button) view.findViewById(R.id.mem_datawrite);
		mem_DataRead = (Button) view.findViewById(R.id.mem_dataread);
		
		mem_DataWrite.setOnClickListener(new Mem_WriteAddr0ToDev());
		mem_DataRead.setOnClickListener(new Mem_ReadAddr0FromDev());
		mem_AddrWrite.setOnClickListener(new Mem_WriteAddr1ToDev());
		mem_AddrRead.setOnClickListener(new Mem_ReadAddr1FromDev());
		operator = new MyOperator();
		
		 if(!multiport.CH341InitMem()) {
			 Toast.makeText(DeviceMEMTestContext, "Init MEM Mode Error", Toast.LENGTH_LONG).show();
		 }
		
		return view;
	}
	
	public class Mem_WriteAddr0ToDev implements View.OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int mLen = 0;
			long iLen = 0;
			String mStr = null;
			char temp[] = new char[512];
			byte ioBuffer[] = new byte[512];
			
			if(!multiport.isConnected()) 
				return;
			
			if(mem_DataLen0 != null) {
				String str = mem_DataLen0.getText().toString();                                      
				if (str != null && str.length() > 0) {                         
					mLen = Integer.parseInt(str);                     
				} 
			}
			
			if(mem_DataText0 != null) {
				mStr = mem_DataText0.getText().toString();
				if(mStr.length() >= mLen * 2) {
					mStr = mStr.substring(0, mLen * 2);
				} else if (mStr.length() % 2 != 0) {
					mStr += "0";
					mLen = mStr.length() / 2;
					mem_DataLen0.setText(Integer.toString(mLen));
				} else {
					mLen = mStr.length() / 2;
					mem_DataLen0.setText(Integer.toString(mLen));
				}
			
				temp = mStr.toCharArray();
				ioBuffer = operator.ToByte(temp);
			}
			
			if(mem_DataLen0 != null && mem_DataText0 != null) {
				iLen = multiport.CH341MEMWriteData(ioBuffer, mLen, 0);
				Log.d(TAG, "WriteData Length is " + iLen);
			} else {
				Toast.makeText(DeviceMEMTestContext, "WriteAddr0��������", Toast.LENGTH_LONG).show();
			}
			
		}
		
	}
	
	public class Mem_ReadAddr0FromDev implements View.OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int mLen = 0, returnLen = 0;
			String mStr = null;
			byte[] readBuffer = new byte[512];
			if(!multiport.isConnected())
				return;
			
			if(mem_DataLen0 != null) {
				String str = mem_DataLen0.getText().toString();
				if(str != null && str.length() > 0) {
					mLen = Integer.parseInt(str);
				}
			}
			
			returnLen = multiport.CH341MEMReadData(readBuffer, mLen, 0);
			if(returnLen > 0) {
				Log.d(TAG, "returnLen is " + returnLen);
				mStr = operator.tostringBuffer(readBuffer, returnLen);
				mem_DataText0.setText(mStr);
			} else {
				mem_DataText0.setText("MEM Read 0 Error");
			}
		}
		
	}
	
	public class Mem_WriteAddr1ToDev implements View.OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int mLen = 0;
			long iLen = 0;
			String mStr = null;
			char temp[] = new char[512];
			byte ioBuffer[] = new byte[512];
			
			if(!multiport.isConnected()) 
				return;
			
			if(mem_DataLen1 != null) {
				String str = mem_DataLen1.getText().toString();                                      
				if (str != null && str.length() > 0) {                         
					mLen = Integer.parseInt(str);                     
				} 
			}
		
			if(mem_DataText1 != null) {
				mStr = mem_DataText1.getText().toString();
				if(mStr.length() >= mLen * 2) {
					mStr = mStr.substring(0, mLen * 2);
				} else if (mStr.length() % 2 != 0) {
					mStr += "0";
					mLen = mStr.length() / 2;
					mem_DataLen1.setText(Integer.toString(mLen));
				} else {
					mLen = mStr.length() / 2;
					mem_DataLen1.setText(Integer.toString(mLen));
				}
			
				temp = mStr.toCharArray();
				ioBuffer = operator.ToByte(temp);
			}
			
			
			if(mem_DataLen1 != null && mem_DataText1 != null) {
				iLen = multiport.CH341MEMWriteData(ioBuffer, mLen, 1);
				Log.d(TAG, "WriteData Length is " + iLen);
			} else {
				Toast.makeText(DeviceMEMTestContext, "WriteAddr0��������", Toast.LENGTH_LONG).show();
			}
			
		}
		
	}
	
	public class Mem_ReadAddr1FromDev implements View.OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int mLen = 0, returnLen = 0;
			String mStr = null;
			byte[] readBuffer = new byte[512];
			if(!multiport.isConnected())
				return;
			
			if(mem_DataLen1 != null) {
				String str = mem_DataLen1.getText().toString();
				if(str != null && str.length() > 0) {
					mLen = Integer.parseInt(str);
				}
			}
			
			returnLen = multiport.CH341MEMReadData(readBuffer, mLen, 1);
			if(returnLen > 0) {
				Log.d(TAG, "returnLen is " + returnLen);
				mStr = operator.tostringBuffer(readBuffer, returnLen);
				mem_DataText1.setText(mStr);
			} else {
				mem_DataText1.setText("MEM Read 1 Error");
			}
		}
		
	}
	
	public void onStart() {
		super.onStart();
	}
	
	public void onDestroy() {
		super.onDestroy();
	}
	
}

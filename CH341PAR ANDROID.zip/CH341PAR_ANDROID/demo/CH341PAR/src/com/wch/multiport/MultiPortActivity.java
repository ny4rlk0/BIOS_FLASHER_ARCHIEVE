package com.wch.multiport;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.app.ListFragment;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

public class MultiPortActivity extends Activity {
	private static final String ACTION_USB_PERMISSION = "com.wch.multiport.USB_PERMISSION";
	public static final String TAG = "MultiPortActivity";
	public static MultiPortManager multiport = null;
	public static int currect_index = 0;
	public static int old_index = -1;
	
	private static Fragment currentFragment = null;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		multiport = new MultiPortManager(
				(UsbManager) getSystemService(Context.USB_SERVICE), this,
				ACTION_USB_PERMISSION);

	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if(2 == multiport.ResumeUsbList()) {
			multiport.CloseDevice();
		}
	}

	public void onDestroy() {
		if(multiport != null) {
			if(multiport.isConnected()) {
				multiport.CloseDevice();
			}
			multiport = null;
		}
		super.onDestroy();
	}
	
	public static class TitlesFragment extends ListFragment {
		boolean mDualPane;      
		int mCurCheckPosition = 0;

		Map<Integer, Fragment> map = new HashMap<Integer, Fragment>();
		
		public TitlesFragment() {
			
		}
		
		@Override      
		public void onActivityCreated(Bundle savedInstanceState) {          
			super.onActivityCreated(savedInstanceState);            // Populate list with our static array of titles.
			
			setListAdapter(new ArrayAdapter<String>(getActivity(),
					android.R.layout.simple_list_item_activated_1, WchModeListInfo.TITLES));      
			
			View detailsFrame = getActivity().findViewById(R.id.details);
			
			mDualPane = detailsFrame != null && detailsFrame.getVisibility() == View.VISIBLE;
			if(savedInstanceState != null) {
				mCurCheckPosition = savedInstanceState.getInt("curChoice", 0);
			}
			
			if(mDualPane) {
				// In dual-pane mode, the list view highlights the selected item.
				getListView().setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
				// Make sure our UI is in the correct state.
                showDetails(mCurCheckPosition);
			}
			
			
		}
		
		public void onSaveInstanceState(Bundle outState) {          
			super.onSaveInstanceState(outState);
			outState.putInt("curChoice", mCurCheckPosition);
		}
		
		
		@Override      
		public void onListItemClick(ListView l, View v, int position, long id) {          
			showDetails(position);      
		}
		
		void showDetails(int index) {
			mCurCheckPosition = index;
			currect_index = index;

			if (mDualPane) {              
				// We can display everything in-place with fragments, so update              
				// the list to highlight the selected item and show the data.              
				getListView().setItemChecked(index, true);	
				Fragment f = map.get(index);
				if(f == null) {
					switch(index) {
					case 0:
						f = new DeviceInformationFragment(getActivity(), multiport);
						break;
					case 1:
						f = new DeviceEPPTestFragment(getActivity(), multiport);
						break;
					case 2:
						f = new DeviceMEMTestFragment(getActivity(), multiport);
						break;
					case 3 :
						f = new DeviceIICTestFragment(getActivity(), multiport);
						break;
					case 4:
						f = new DeviceFLASHTestFragment(getActivity(), multiport);
						break;
					default:
						f = new DetailsFragment();
						break;
					}
					map.put(index, f);
					Bundle args = new Bundle();
					args.putInt("index", index);
					f.setArguments(args);
				} 
				
				currentFragment = f;
				
//				if(currect_index != old_index) 
				{
					 FragmentTransaction ft = getFragmentManager().beginTransaction();
		             ft.replace(R.id.details, f);
		             ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
		             ft.commit();
				}
				old_index = currect_index;
			} else {
			    // Otherwise we need to launch a new activity to display
                // the dialog fragment with selected text.
                Intent intent = new Intent();
                intent.setClass(getActivity(), DetailsActivity.class);
                intent.putExtra("index", index);
                startActivity(intent);	
			}
		}
	}
	
	  /**
     * This is the secondary fragment, displaying the details of a particular
     * item.
     */
    public static class DetailsFragment extends Fragment {
    	
     	public DetailsFragment() {

    	}

        public int getShownIndex() {
            return getArguments().getInt("index", 0);
        }
    	
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
        	if(container == null) {
        		return null;
        	}
        	 ScrollView scroller = new ScrollView(getActivity());
             TextView text = new TextView(getActivity());
             int padding = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                     4, getActivity().getResources().getDisplayMetrics());
             text.setPadding(padding, padding, padding, padding);
             scroller.addView(text);
             text.setText(WchModeListInfo.DIALOGUE[getShownIndex()]);
             return scroller;
        }
        
    }
	
	public static class DetailsActivity extends Activity {
		Map<Integer, Fragment> act_map = new HashMap<Integer, Fragment>();

		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			if(getResources().getConfiguration().orientation
					== Configuration.ORIENTATION_LANDSCAPE) {
				finish();
				return;
			}
			if(savedInstanceState == null) {
				Fragment f = act_map.get(currect_index);
				if(f == null) {
					switch(currect_index) {
					case 0:
						f = new DeviceInformationFragment(this, multiport);
						break;
					case 1:
						f = new DeviceEPPTestFragment(this, multiport);
						break;
					case 2:
						f = new DeviceMEMTestFragment(this, multiport);
						break;
					case 3 :
						f = new DeviceIICTestFragment(this, multiport);
						break;
					case 4:
						f = new DeviceFLASHTestFragment(this, multiport);
						break;
					default:
						f = new DetailsFragment();
						break;
					}
					act_map.put(currect_index, f);
					f.setArguments(getIntent().getExtras());
					getFragmentManager().beginTransaction().add(android.R.id.content, f).commit();
				}
				currentFragment = f;
			}
		}
	}

}

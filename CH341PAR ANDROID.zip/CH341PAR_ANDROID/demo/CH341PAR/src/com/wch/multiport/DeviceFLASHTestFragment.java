package com.wch.multiport;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Toast;

@SuppressLint("ValidFragment")
public class DeviceFLASHTestFragment extends Fragment {
	static Context DeviceFLASHTestContext;
	MultiPortManager multiport;
	EditText flash_readText, flash_writeText;
	EditText flash_ReadDataLen, flash_ReadDataAddr, flash_WriteDataLen, flash_WriteDataAddr;
	Spinner flash_DevSelection;
	Button flash_WriteBtn, flash_ReadBtn;
	String flash_devname;
	int flash_Selection = 0;
	MyOperator operator;
	
	// Empty Constructor
	public DeviceFLASHTestFragment()
	{
	}
	
	/* Constructor */
	public DeviceFLASHTestFragment(Context parentContext , MultiPortManager MultiPortContext)
	{
		DeviceFLASHTestContext = parentContext;
		multiport = MultiPortContext;
	}
	
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
					Bundle savedInstanceState)
	{
		if(container == null) {
			return null;
		}
		
		View flashView = inflater.inflate(R.layout.flash_layout, container, false);
		
		flash_readText = (EditText) flashView.findViewById(R.id.ReadValues);
		flash_writeText = (EditText) flashView.findViewById(R.id.WriteValues);
		flash_ReadDataLen = (EditText) flashView.findViewById(R.id.ReadDataLen);
		flash_WriteDataLen = (EditText) flashView.findViewById(R.id.WriteDataLen);
		flash_ReadDataAddr = (EditText) flashView.findViewById(R.id.ReadDataAddr);
		flash_WriteDataAddr = (EditText) flashView.findViewById(R.id.WriteDataAddr);
		flash_ReadBtn = (Button) flashView.findViewById(R.id.ReadButton);
		flash_WriteBtn = (Button) flashView.findViewById(R.id.WriteButton);
		
		flash_DevSelection = (Spinner) flashView.findViewById(R.id.DeviceType);
		
		ArrayAdapter<CharSequence> flash_typeAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.flash_type,
				R.layout.my_spinner_textview);
		flash_typeAdapter.setDropDownViewResource(R.layout.my_spinner_textview);		
		flash_DevSelection.setAdapter(flash_typeAdapter);
		flash_DevSelection.setGravity(0x10);
		flash_DevSelection.setSelection(0);
		
		flash_DevSelection.setOnItemSelectedListener(new MyFlashNameSelectedListener());
		flash_ReadBtn.setOnClickListener(new MyReadFlashByteListener());
		flash_WriteBtn.setOnClickListener(new MyWriteFlashByteListener());
		operator = new MyOperator();
		return flashView;
	}
	
	public class MyReadFlashByteListener implements View.OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			long mLen = 0;
			long iAddr = 0;
			String mStr;
			
			if(!multiport.isConnected()) 
				return;
			
			if(flash_ReadDataLen != null) {
				String strLen = flash_ReadDataLen.getText().toString();
				if(strLen != null && strLen.length() > 0) {
					mLen = Integer.parseInt(strLen);
				}
			}
			
			if(flash_ReadDataAddr != null) {
				String strAddr = flash_ReadDataAddr.getText().toString();
				if(strAddr != null && strAddr.length() > 0) {
					iAddr = Integer.parseInt(strAddr);
				}
			}
			
			if(flash_ReadDataLen != null && flash_ReadDataAddr != null) {
				multiport.SetDeviceType(0);
				mStr = multiport.Ch341FlashReadByte(iAddr, mLen);
				if(mStr != null) {
					flash_readText.setText(mStr);
				} else {
					flash_readText.setText("Flash Read Error");
				}
			} else {
				flash_readText.setText("�������㵼�¶�����ʧ��");
			}
			
		}
		
	}
	
	public class MyWriteFlashByteListener implements View.OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			long mLen = 0;
			long oAddr = 0;
			String mStr = null;
			boolean retval;
			if(!multiport.isConnected())
				return;
			
			if(flash_WriteDataLen != null) {
				String strLen = flash_WriteDataLen.getText().toString();
				if(strLen != null && strLen.length() > 0) {
					mLen = Integer.parseInt(strLen);
				}
			}
			
			if(flash_WriteDataAddr != null) {
				String strAddr = flash_WriteDataAddr.getText().toString();
				if(strAddr != null && strAddr.length() > 0) {
					oAddr = Integer.parseInt(strAddr);
				}
			}
			
			if(flash_WriteDataLen != null && flash_WriteDataAddr != null) {
				multiport.SetDeviceType(0);
				if(flash_writeText != null) {
					mStr = flash_writeText.getText().toString();
					retval = multiport.Ch341WriteSpi(oAddr, mLen, mStr);
					if(retval) {
						Toast.makeText(DeviceFLASHTestContext, "WriteFlash Sucess", Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(DeviceFLASHTestContext, "WriteFlash Failed", Toast.LENGTH_SHORT).show();
					}
				} else {
					flash_readText.setText("�������㵼��д����ʧ��");
				}
			} else {
				flash_readText.setText("�������㵼��д����ʧ��");
			}
		}
		
	}
	
	public class MyFlashNameSelectedListener implements OnItemSelectedListener {
		public void onItemSelected(AdapterView<?> parent, View view, int pos,
				long id) {

			flash_devname = parent.getItemAtPosition(pos).toString();
		}

		public void onNothingSelected(AdapterView<?> parent) { // Do nothing. }}
		}
	}
	
	public void onStart() {
		super.onStart();
	}
	
	public void onDestroy() {
		super.onDestroy();
	}
	
}

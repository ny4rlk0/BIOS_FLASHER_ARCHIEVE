package com.wch.multiport;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("ValidFragment")
public class DeviceInformationFragment extends Fragment {
	static Context DeviceInformationContext;
	MultiPortManager multiport;
	Button btnRefreshDevice, get_param, get_pidvid;
	TextView devName, DeviceDescription, Library;
	EditText ChipVersion, bufsizeValue, transizeValue, readtimeValue, writetimeValue;
	ScrollView scrollview;
	TextView readText;
	
	
	// Empty Constructor
	public DeviceInformationFragment()
	{
	}
	
	/* Constructor */
	public DeviceInformationFragment(Context parentContext , MultiPortManager MultiPortContext)
	{
		DeviceInformationContext = parentContext;
		multiport = MultiPortContext;
	}
	
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState)
	{
		if(container == null) {
			return null;
		}
		View view = inflater.inflate(R.layout.device_information, container, false);
		
		devName = (TextView)view.findViewById(R.id.devName);
		DeviceDescription = (TextView)view.findViewById(R.id.device_information_description);
		Library = (TextView)view.findViewById(R.id.device_informatation_library);
		readText = (TextView)view.findViewById(R.id.ReadValues);
		ChipVersion = (EditText)view.findViewById(R.id.ChipVersion);
		bufsizeValue = (EditText)view.findViewById(R.id.bufsizeValue);
		transizeValue = (EditText)view.findViewById(R.id.transizeValue);
		readtimeValue = (EditText)view.findViewById(R.id.readtimeValue);
		writetimeValue = (EditText)view.findViewById(R.id.writetimeValue);
		btnRefreshDevice = (Button)view.findViewById(R.id.device_informatation_refresh);
		get_param = (Button)view.findViewById(R.id.get_param);
		get_pidvid = (Button)view.findViewById(R.id.get_pidvid);
		scrollview = (ScrollView)view.findViewById(R.id.ReadField);

		
		btnRefreshDevice.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(multiport.isConnected())
					GetDisplayView();
				else
					Toast.makeText(DeviceInformationContext, "NG: Device Disconnect!!", Toast.LENGTH_LONG).show();
			}
		});
		
		get_pidvid.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(multiport.isConnected()) {
					Get_PIDVID_Click(v);
				} else {
					Toast.makeText(DeviceInformationContext, "NG: Device Disconnect!!", Toast.LENGTH_LONG).show();
				}
			}
		});
	
		get_param.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int bufsize, transfersize, readtimeout, writetimeout;
	
				if(multiport.isConnected()) {
					int retval = multiport.CH341SystemInit();
					if(retval < 0) {
						Toast.makeText(DeviceInformationContext, "System Init Error", Toast.LENGTH_SHORT).show();
						ChipVersion.setText("Cannot Get ChipVersion");
					} else {
						ChipVersion.setText(Integer.toString(multiport.CH341GetChipVersion()));
					}
					bufsize = multiport.CH341GetBufSizeValue();
					transfersize = multiport.CH341TransPackageSize();
					readtimeout = multiport.CH341GetReadTimeOutValue();
					writetimeout = multiport.CH341GetWriteTimeOutValue();
					bufsizeValue.setText(Integer.toString(bufsize));
					transizeValue.setText(Integer.toString(transfersize));
					readtimeValue.setText(Integer.toString(readtimeout));
					writetimeValue.setText(Integer.toString(writetimeout));
					
				} else {
					Toast.makeText(DeviceInformationContext, "NG: Device Disconnect!!", Toast.LENGTH_LONG).show();
				}
			}
		});
		
		return view;
	}
	@Override
	public void onStart() {
		InitDisplayView();
	    super.onStart();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}
	
	public void Get_PIDVID_Click(View view) {
		int[][] arrayPIDVID = multiport.CH341GetPIDVID();
		int len = arrayPIDVID[0].length;
		
		for(int i = 0; i < len; i++) {
			String temp = "" + i + ".VID:" + Integer.toHexString(arrayPIDVID[0][i]) +
					"	PID:" + Integer.toHexString(arrayPIDVID[1][i]) + "\n";
			String tmp = temp.replace("\\n", "\n");
			readText.append(tmp);
		}
		
		readText.append("END");
	}
	
	public void GetDisplayView()
	{
		boolean flag;
		flag = multiport.isConnected();
		if(flag) {
			devName.setText("Device Name : " + multiport.CH341GetDevName());
			DeviceDescription.setText("Device Description: " + multiport.CH341GetDescription());
			Library.setText("Library Version: " + multiport.CH341GetLibraryVendor());
		} else {
			Toast.makeText(DeviceInformationContext, "NG: NO Device Attached", Toast.LENGTH_SHORT).show();
		}
	}
	
	public void InitDisplayView()
	{
		devName.setText("Device Name : No device");
		DeviceDescription.setText("Device Description: ");
		Library.setText("Library Version: ");
	}
	
}
